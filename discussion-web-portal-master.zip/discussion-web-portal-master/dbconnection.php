<?php
$db="web_portal";
$host="localhost";
$user="root";
$pwd="";
$con=mysqli_connect($host,$user,$pwd,$db);
if(!$con)
{
	die("SQL connection error");
}
//web_portal
//karthick_webportal
//user = id8864124_karthick_webportal
//pwd = 11221122
//dbname = id8864124_web_portal
?>
